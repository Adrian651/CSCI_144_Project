******LIBRARIES******

I used thread library, because i felt it was easier to use and understand. 
I included Chorono to use time for sleep. 
Included Fstream to read in the file.


***********PLATFORM***********

I ran it on IOS operating system. Uinsg XCode. I am not sure if the program will work on windows.
I compiled it on the IDE Xcode. However it did also run in the terminal. using UNIX. 

-- g++ -std=c++11 main.cpp 
./a.out 

*******MAIN*******

 The program runs well using server thread. However if you were to want a faster result. Comment out the sleep variables, and comment out where you would create the Server thread. As well as where it joins. 

 *** IF any questions Feel free to contact me @adrian651@mail.FresnoState.edu